public interface Estado {

    String estadoAtual();

    void verificaAssinatura(Cliente cliente, Boolean pagou);

    void Assinar(Cliente cliente);

    int getMensalidade();

    double getDesconto(Cliente cliente);

}
