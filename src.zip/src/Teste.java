import java.util.ArrayList;

public class Teste {
    public static void main(String[] args) {
        SistemaVendas sistema = SistemaVendas.getInstance();
        Endereço teste = new Endereço("SP", "SP", "BR", "11");
        Cliente cliente1 = new Cliente(1,1,"Ma",teste,"A");
        Cliente cliente2 = new Cliente(2,30,"Nara",teste,"A");
        Evento evento1 = new Evento(1, "20/10", "18:00", "aqui", 60, 10, 5);
        

        sistema.novoCliente(cliente1);
        sistema.novoCliente(cliente2);
        sistema.novoEvento(evento1);

        System.out.println(cliente1.getEstado().estadoAtual());
        cliente1.getEstado().Assinar(cliente1);
        System.out.println(cliente1.getEstado().estadoAtual());
        cliente1.getEstado().verificaAssinatura(cliente1, false);
        System.out.println(cliente1.getEstado().estadoAtual());
        System.out.println(cliente1.getEstado().getMensalidade());
        System.out.println(cliente1.getEstado().getDesconto(cliente1));
        cliente1.getEstado().Assinar(cliente1);
        System.out.println(cliente1.getEstado().estadoAtual());
        System.out.println(cliente1.getEstado().getDesconto(cliente1));
        System.out.println(cliente1.getEstado().getMensalidade());
        
        //- - - - -- ---- -- - - - - - 

        Ingresso ingresso1 = new Ingresso(cliente1, evento1, 1, 1);
        Ingresso ingresso2 = new Ingresso(cliente1, evento1, 1, 2);
        Ingresso ingresso3 = new Ingresso(cliente1, evento1, 1, 3);
        Ingresso ingresso4 = new Ingresso(cliente1, evento1, 1, 4);
        ArrayList<Ingresso> ingressos = new ArrayList<>();
        ingressos.add(ingresso1);
        ingressos.add(ingresso2);
        ingressos.add(ingresso3);
        ingressos.add(ingresso4);
        
        Venda venda1 = new Venda(ingressos);

        System.out.println(venda1.getCodigos());
        System.out.println(venda1.getVenda());
        

        Ingresso ingresso5 = new Ingresso(cliente1, evento1, 1, 5);
        venda1.compraIngresso(ingresso5);

        System.out.println(venda1.getCodigos());
        System.out.println(venda1.getVenda());
        

        Ingresso ingresso6 = new Ingresso(cliente2, evento1, 1, 6);
        Ingresso ingresso7 = new Ingresso(cliente2, evento1, 1, 7);
        Ingresso ingresso8 = new Ingresso(cliente2, evento1, 1, 8);
        Ingresso ingresso9 = new Ingresso(cliente2, evento1, 1, 9);

        ArrayList<Ingresso> ingressos2 = new ArrayList<>();
        ingressos2.add(ingresso6);
        ingressos2.add(ingresso7);
        ingressos2.add(ingresso8);
        ingressos2.add(ingresso9);

        System.out.println(cliente2.getEstado().estadoAtual());
        Venda venda2 = new Venda(ingressos2); 
        System.out.println(venda2.getCodigos());
        System.out.println(venda2.getVenda());




        sistema.novaVenda(venda1);
        sistema.novaVenda(venda2);

        sistema.geraRelatorioEvento(evento1);
        
    }   
}
