public class Evento {
    private int codigo_evento;
    private String Data;
    private String hora;  
    private String Local;
    private int QtdIng;
    private int valor;
    private int idade;

    public Evento(int codigo_evento, String Data, String hora, String Local, int QtdIng, int valor, int idade){
        this.codigo_evento = codigo_evento;
        this.Data = Data;
        this.hora = hora;
        this.Local = Local;
        this.QtdIng = QtdIng;
        this.valor = valor;
        this.idade = idade;
    }


    public int getCodigo_evento() {
        return codigo_evento;
    }

    public void setCodigo_evento(int codigo_evento) {
        this.codigo_evento = codigo_evento;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLocal() {
        return Local;
    }

    public void setLocal(String local) {
        Local = local;
    }

    public int getQtdIng() {
        return QtdIng;
    }

    public void setQtdIng(int qtdIng) {
        QtdIng = qtdIng;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String toString(){
        String res = "---Evento---\n";
              res += " Data: " + Data;
              res += "\n hora: " + hora;
              res += "\n Local: " + Local;
              res += "\n Ingressos: " + QtdIng;
              res += "\n valor: " + valor;
              res += "\n Idade: " + idade;
        return res;
    }
}
