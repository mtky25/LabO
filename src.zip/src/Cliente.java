public class Cliente{
    private int cpf;
    private int idade;
    private String nome;
    private Endereço endereço;
    private String email;
    private Estado estado;

   

    public Cliente (int cpf,int idade,String nome,Endereço endereço,String email){
        this.cpf = cpf;
        this.idade = idade;
        this.nome = nome;
        this.endereço = endereço;
        this.email = email;
        this.estado = new EstadoEventual();
    };
    
     public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

       public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Endereço getEndereço() {
        return endereço;
    }

    public void setEndereço(Endereço endereço) {
        this.endereço = endereço;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }


}