import java.util.ArrayList;

public class SistemaVendas {

    private ArrayList<Evento> eventosDB = new ArrayList<>();
    private ArrayList<Cliente> clientesDB = new ArrayList<>();
    private ArrayList<Venda> vendasDB = new ArrayList<>();
    private static SistemaVendas instance;
    
    private SistemaVendas() {}

    public static SistemaVendas getInstance(){
        if (instance == null)
            instance = new SistemaVendas();
        return instance;
    }

    public void novoCliente (Cliente cliente){
        clientesDB.add(cliente);
    }

    public void novoEvento (Evento evento){
        eventosDB.add(evento);
    }

    public void novaVenda (Venda venda){
        vendasDB.add(venda);
    }

    public void geraRelatorioEvento(Evento evento){
        int i = 1;
        double receitaLiquida = 0;
        int ingressosVendidos = 0;
        double impostosRecolhidos = 0;
        double quantiaComercializada;
        for (Venda venda: vendasDB){
            if(evento.getCodigo_evento() == venda.ingressos.get(0).getEvento().getCodigo_evento()){
                receitaLiquida += venda.getVenda();
                impostosRecolhidos += venda.getImpostoRecolhido();
                ingressosVendidos += venda.getCodigos().size();               
            }
        }
        System.out.println(" Relatório Evento " + evento.getCodigo_evento() + "\nReceitaLiquida: " + receitaLiquida + "\nImpostos: " + impostosRecolhidos + "\nIngressos Vendidos: " + ingressosVendidos + "\nIngressos Disponíveis: " + (evento.getQtdIng() - ingressosVendidos));
    }

}
