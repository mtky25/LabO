public class EstadoEventual implements Estado{
    
    public static EstadoEventual instance = new EstadoEventual();

    @Override
    public String estadoAtual() {
        return "Eventual";
    }

    @Override
    public void verificaAssinatura(Cliente cliente, Boolean pagou) {
        System.out.println("Não tem assinatura.");
    }

    @Override
    public void Assinar(Cliente cliente) {
        cliente.setEstado(EstadoAssiduo.instance);

    }

    @Override
    public int getMensalidade() {
        System.out.println("Não paga Mensalidade!");
        return 0;
    }

    @Override
    public double getDesconto(Cliente cliente) {
        if (cliente.getIdade() < 25)
            return 0.5;
        return 1.0;

    }

}
