import java.util.ArrayList;

public class Venda {

    ArrayList<Ingresso> ingressos = new ArrayList<>();

    public Venda (ArrayList<Ingresso> ingressos) {
        this.ingressos = ingressos;
    }
    
    public void compraIngresso(Ingresso ingresso){
        ingressos.add(ingresso);
    }

    public double getVenda(){
        double valor = 0.0;
        Ingresso ingresso = this.ingressos.get(0);                      //como todos os ingressos tem um dono, podemos generalizá-lo.
        double desconto = ingresso.getDono().getEstado().getDesconto(ingresso.getDono());
        double taxa_conveniencia = ingresso.getTaxa();
        valor = (ingresso.getEvento().getValor() * ingressos.size() * desconto)*(1+this.getImposto()) + taxa_conveniencia;

        return valor;
    }


    public double getImpostoRecolhido(){
        Ingresso ingresso = this.ingressos.get(0);
        return (ingresso.getEvento().getValor() * ingressos.size() * ingresso.getDono().getEstado().getDesconto(ingresso.getDono()))*this.getImposto();
    }

    public double getImposto(){
        return 0.12;
    }


    public ArrayList<Integer> getCodigos(){
        ArrayList<Integer> codigos = new ArrayList<>();
        for (Ingresso ingresso : this.ingressos){
            codigos.add(ingresso.getCodigo());
        }
        return codigos;
    }



}
