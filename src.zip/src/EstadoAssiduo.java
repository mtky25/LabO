public class EstadoAssiduo implements Estado {

    public static EstadoAssiduo instance = new EstadoAssiduo();

    @Override
    public String estadoAtual() {
        return "Assiduo";
    }

    @Override
    public void verificaAssinatura(Cliente cliente, Boolean pagou) {
        if (pagou == false)
            cliente.setEstado(EstadoEventual.instance);
    }

    @Override
    public void Assinar(Cliente cliente) {
        System.out.println("Já é Assíduo!");
    }

    @Override
    public int getMensalidade() {
        return 50;
    }

    @Override
    public double getDesconto(Cliente cliente) {
        return 0.4;
    }
    
}
