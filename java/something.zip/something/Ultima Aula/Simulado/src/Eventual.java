public class Eventual implements Cliente{
    static final int MENSALIDADE = 0;
    static final double IMPOSTO = 0.0;
    static final double DESCONTO = 0.0;

        private int CPF;
        private int idade;
        private String nome;
        private String email;
        private Endereço endereço;
        private int telefone;

    public Eventual ( int CPF,int idade, String nome,String email,Endereço endereço,int telefone,int assinatura){
        this.CPF = CPF;
        this.idade = idade;
        this.nome = nome;
        this.email = email;
        this.endereço = endereço;
        this.telefone = telefone;
    }    

    public int getCPF() {
            return CPF;
        }


    public void setCPF(int cPF) {
            CPF = cPF;
        }


    public int getIdade() {
            return idade;
        }


    public void setIdade(int idade) {
            this.idade = idade;
        }


    public String getNome() {
            return nome;
        }


    public void setNome(String nome) {
            this.nome = nome;
        }


    public String getEmail() {
            return email;
        }


    public void setEmail(String email) {
            this.email = email;
        }


    public Endereço getEndereço() {
            return endereço;
        }


    public void setEndereço(Endereço endereço) {
            this.endereço = endereço;
        }


    public int getTelefone() {
            return telefone;
        }


    public void setTelefone(int telefone) {
            this.telefone = telefone;
        }



    public int getMensalidae(){ 
            return MENSALIDADE;
    }


    public double getDesconto(){
        return DESCONTO;
    }

    public String toString(){
        String res = " Nome: " + nome;
        res += "\n CPF: " + CPF;
        res += "\n Idade: " + idade;
        res += "\n Email: " + email;
        res += endereço;
        res += "\n Telefone: " + telefone;
        return res;
    }
}