public class Endereço {
        String cidade;
        String estado;
        String país;
        String logradouro;

    public Endereço(String cidade, String estado, String país, String logradouro){
        this.cidade = cidade;
        this.estado = estado;
        this.país = país;
        this.logradouro = logradouro;
    }

    public String toString(){
        String res = "\n---Endereço---\n";
              res += " Cidade: " + cidade;
              res += "\n Estado: " + estado;
              res += "\n País: " + país;
              res += "\n logradouro: " + logradouro;
        return res;
    }
}
