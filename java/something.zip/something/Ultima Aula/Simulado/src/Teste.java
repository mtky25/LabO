public class Teste {
    public static void main(String[] args) {
        Endereço teste = new Endereço("null", "null", "null", "null");
        Cliente cliente1 = new Assiduo(1,1,"a","a",teste,1,1);
        Evento evento1 = new Evento(1, "20/10", "18:00", "aqui", 60, 5, 5);
        Ingresso ingresso1 = new Ingresso(cliente1, evento1, 1, 2);
        System.out.println(ingresso1);
        
    }   
}
