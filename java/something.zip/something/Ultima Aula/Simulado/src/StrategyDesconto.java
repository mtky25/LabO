public interface StrategyDesconto{

    public double getDesconto();
}
