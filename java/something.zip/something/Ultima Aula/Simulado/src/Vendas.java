public class Vendas {
    double valor;
    Ingresso ingresso;
    Cliente cliente;

    public Vendas(double valor,Cliente cliente, Ingresso ingresso){
        this.valor = valor;
        this.ingresso =  ingresso;
        this.cliente =  cliente;
    }

     public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double preco_final(Evento evento, Cliente cliente){

            double desconto = cliente.getDesconto();

            if(cliente.idade < 25){
                valor += 0.5*evento.getValor();
                valor += imposto*valor;
            }
            else{
                valor += desconto*evento.getValor();
                valor += imposto*valor;
            }
            
            valor += ingresso.TAXA_CONVENIENCIA;
    }


    public double impostosRecolhidos(Cliente[] clientes){
        double imposto = 0;
        for (Cliente cliente: clientes){
            double imposto_cliente = cliente.getImposto();
            for (Ingresso ingresso: cliente.ingressos){
                    imposto += ingresso.evento.valor * imposto_cliente;
            }
        }
        return imposto;
    }

    public double receitaLiquida(Cliente[] clientes){
        double receita = 0;
            for (Cliente cliente: clientes){
            double imposto_cliente = cliente.getImposto();
            for (Ingresso ingresso: cliente.ingressos){
                    receita += ingresso.evento.valor - imposto_cliente*ingresso.evento.valor - ingresso.TAXA_CONVENIENCIA;

            }
        }
        return receita;
    }
}