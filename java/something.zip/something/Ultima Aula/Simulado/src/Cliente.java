public interface Cliente {

    public int getMensalidae();

    public double getDesconto();

    public String toString();

}


