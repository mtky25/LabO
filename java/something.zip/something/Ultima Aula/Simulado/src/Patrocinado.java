public class Patrocinado extends Evento{
    
}
