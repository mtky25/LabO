public class Naopatrocinado extends Evento{
    
}
