public class Ingresso {
    private int codigo;
    private Cliente dono;
    private Evento evento;
    private int retira;

    public Ingresso(Cliente dono,Evento evento, int retira,int codigo){
        this.dono = dono;
        this.evento = evento;
        this.retira = retira;
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Cliente getDono() {
        return dono;
    }

    public void setDono(Cliente dono) {
        this.dono = dono;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public int getRetira() {
        return retira;
    }

    public void setRetira(int retira) {
        this.retira = retira;
    }

    

    public String toString(){
        String res = "--Ingresso " + codigo + "--\n";
        res += dono.toString();
        res += evento.toString();
        if(retira == 1)
        res += "\n Ingresso retirado";
        else
        res += "\n Ingresso recebido em casa";
        return res;

    }
}
