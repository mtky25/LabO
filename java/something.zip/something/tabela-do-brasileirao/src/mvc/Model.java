package src.mvc;

import java.util.Collection;

// Interface para modelo
// -- permite que troquemos no futuro

public interface Model {
    void addResult(String team1, int goals1, String team2, int goals2);
    public Collection<TeamScore> getResults();
    void populate();
}
