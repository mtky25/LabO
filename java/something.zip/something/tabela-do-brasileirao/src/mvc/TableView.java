package src.mvc;


// Visão de tabela com botões
// Lembre-se: você copiou isso de outro projeto e precisa ainda
// modificar para se adequar ao projeto atual

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class TableView implements View {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;

    private Controller controller;
    private Model model;

    public TableView(Controller theController, Model theModel) {

        controller = theController;

        model = theModel;

    }

    public void createView() {

        frame = new JFrame("Tabela do Brasileirão");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"Nome", "Idade", "Peso"}
        );
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new GridLayout(1, 2));
        frame.add(btnPanel, BorderLayout.SOUTH);

        JButton addPersonButton = new JButton("Nova Pessoa");
        addPersonButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nome = JOptionPane.showInputDialog(frame, "Nome completo:");
                int idade = Integer.parseInt(JOptionPane.showInputDialog(frame, "Idade (anos):"));
                int peso = Integer.parseInt(JOptionPane.showInputDialog(frame, "Peso (kg):"));
                tableModel.addRow(new Object[] { 
                    nome, idade, peso
                });
                table.repaint();
            }            
        });
        btnPanel.add(addPersonButton);

        JButton sortButton = new JButton("Ordenar");
        sortButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // TO-DO
            }
        });
        btnPanel.add(sortButton);

    }

    public void displayTable() {
        // pega dados do modelo e os insere na tabela
        table.repaint();
    }

    public void show() {
        createView();

        displayTable();
        
        frame.setVisible(true);
    }

}
