package src.mvc;

import java.util.Scanner;

// Um controlador que apenas instancia a visão

public class DummyController implements Controller {
    
    View view;
    Model model;

    public DummyController(Model theModel) {

        view = new TableView(this, theModel);
        
        model = theModel;

        view.show();
    
    }

    

    public static void main(String[] args) {
        
        Model theModel = new ResultsModel();

        Controller theController = new DummyController(theModel);            
    
    }



    @Override
    public void name() {
        Scanner scan = new Scanner(System.in);
        String time1, time2;
        System.out.println("Time 1: ");

    }

}
