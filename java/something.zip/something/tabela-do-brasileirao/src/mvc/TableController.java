package src.mvc;


public class TableController implements Controller {

    private View view;
    private ResultsModel model;

    public TableController(ResultsModel theModel) {
        view = new TableView(this, theModel);
        
        model = theModel;

        view.show();
    }         

    public void addResult(String team1, int goals1, String team2, int goals2) {
            
        model.addResult(team1, goals1, team2, goals2);
            
        view.displayTable();            
    }

    // Make fake data
    public void populate() {

        System.out.println("populating data model...");

        model.populate();

        view.displayTable();
    }

}

