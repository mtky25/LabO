package src.mvc;


// Interface para visão
// -- permite que troquemos no futuro

public interface View {
    public void show();
    public void displayTable();
}
