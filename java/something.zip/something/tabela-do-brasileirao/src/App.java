package src;

import src.mvc.Controller;
import src.mvc.DummyController;
import src.mvc.Model;
import src.mvc.ResultsModel;

// Aplicação

public class App {
    public static void main(String[] args) {
        Model theModel = new ResultsModel();

        Controller theController = new DummyController(theModel);    
    }
}
